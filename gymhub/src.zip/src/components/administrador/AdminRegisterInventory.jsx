import React, { useEffect, useState } from 'react';
import { agregarProducto } from '../../cruds/InventoryCrud';
import Swal from 'sweetalert2';
import { Trash, Plus } from 'lucide-react';
import '../../css/AdminRegisterInventory.css';

const AdminRegisterInventory = ({ selectedGym, onClose }) => {
  const [inventory, setInventory] = useState([]);
  const [newItem, setNewItem] = useState({ nombre: '', cantidad: '', categoria: '', estado: '', ejercicios: [] });
  const [newExercise, setNewExercise] = useState({ nombre: '', descripcion: '', zonas: [] });
  const [newZone, setNewZone] = useState('');

  const handleAddItem = async () => {
    try {
      newItem.ejercicios = [...newItem.ejercicios, newExercise];
      await agregarProducto(selectedGym, newItem);
      setInventory([...inventory, newItem]);
      setNewItem({ nombre: '', cantidad: '', categoria: '', estado: '', ejercicios: [] });
      setNewExercise({ nombre: '', descripcion: '', zonas: [] });
      Swal.fire('Agregado', 'Producto agregado correctamente', 'success');
    } catch (error) {
      console.error("Error adding item:", error);
    }
  };

  const addExercise = () => {
    setNewItem({
      ...newItem,
      ejercicios: [...newItem.ejercicios, newExercise]
    });
    setNewExercise({ nombre: '', descripcion: '', zonas: [] });
  };

  const removeExercise = (index) => {
    setNewItem({
      ...newItem,
      ejercicios: newItem.ejercicios.filter((_, i) => i !== index)
    });
  };

  

  const addZone = () => {
    setNewExercise({
      ...newExercise,
      zonas: [...newExercise.zonas, newZone]
    });
    setNewZone('');
  }

  const removeZone = (index) => {
    setNewExercise({
      ...newExercise,
      zonas: newExercise.zonas.filter((_, i) => i !== index)
    });
  }


  return (
    <div className="admin-inventory-register-view">
      <div className="register--header">
        <h2>Agregar Equipo</h2>
      </div>
      <div className="inventory-form">

        <input
          type="text"
          placeholder="Nombre del producto"
          value={newItem.nombre}
          onChange={e => setNewItem({ ...newItem, nombre: e.target.value })}
        />
        <input
          type="number"
          placeholder="Cantidad"
          value={newItem.cantidad}
          onChange={e => setNewItem({ ...newItem, cantidad: e.target.value })}
        />
        <input
          type="text"
          placeholder="Categoría"
          value={newItem.categoria}
          onChange={e => setNewItem({ ...newItem, categoria: e.target.value })}
        />
        <select
          value={newItem.estado}
          onChange={e => setNewItem({ ...newItem, estado: e.target.value })}
        >
          <option value="">Estado</option>
          <option value="Operativo">Operativo</option>
          <option value="En mantenimiento">En mantenimiento</option>
          <option value="Fuera de servicio">Fuera de servicio</option>
        </select>

        <div className="exercise-form">
          <input
            type="text"
            placeholder="Nombre del ejercicio"
            value={newExercise.nombre}
            onChange={e => setNewExercise({ ...newExercise, nombre: e.target.value })}
          />
          <input
            type="text"
            placeholder="Descripción del ejercicio"
            value={newExercise.descripcion}
            onChange={e => setNewExercise({ ...newExercise, descripcion: e.target.value })}
          />

          <div className="zone-form">
            <input
              type="text"
              placeholder="Zona del cuerpo"
              value={newZone}
              onChange={e => setNewZone(e.target.value)}
            />
            <button type="button" onClick={addZone}><Plus /> Agregar Zona</button>
          </div>

          <ul className="zone-list">
            {newExercise.zonas.map((zona, index) => (
              <li key={index}>
                {zona}
                <button onClick={() => removeZone(index)}>Eliminar</button>
              </li>
            ))}
          </ul>

          <button type="button" onClick={addExercise}><Plus /> Agregar Ejercicio</button>
        </div>

        <button onClick={handleAddItem}><Plus /> Agregar Producto</button>
      </div>


    </div>
  );
}

export default AdminRegisterInventory;
