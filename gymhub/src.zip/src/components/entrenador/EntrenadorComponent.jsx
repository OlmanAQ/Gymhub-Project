import React from 'react'
import EntrenadorNavBarComponent from './EntrenadorNavBarComponent'


const EntrenadorComponent = () => {
  return (
    <EntrenadorNavBarComponent />
)
}

export default EntrenadorComponent