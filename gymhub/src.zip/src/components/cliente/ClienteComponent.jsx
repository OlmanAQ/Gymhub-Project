import React from 'react'
import ClientNavBarComponent from './ClientNavBarComponent'


const ClienteComponent = () => {
  return (
    <ClientNavBarComponent />
)
}

export default ClienteComponent