import './App.css';
import InicioSesionComponet from './components/registro-login/InicioSesionComponent';
function App() {
  return (
    <div className="App">
      <InicioSesionComponet/>
    </div>
  );
}

export default App;
